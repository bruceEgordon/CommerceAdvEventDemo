﻿define("epi-ecf-ui/command/PasteCatalogContent", [
    // dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/promise/all",
    "dojo/when",

    // framework
    "epi/shell/TypeDescriptorManager",

    // cms
    "epi-cms/command/PasteContent",

    // epi-ecf-ui
    "../contentediting/ModelSupport"
],

    function (
        // dojo
        array,
        declare,
        promiseAll,
        when,

        // framework
        TypeDescriptorManager,

        // cms
        PasteContent,

        // epi-ecf-ui
        ModelSupport
    ) {

        // module:
        //      epi-ecf-ui/command/PasteCatalogContent
        // summary:
        //      A command that pastes whats in the clip board onto the current selection.
        //      Inherits from the general content past command in cms, and changes behaviour when the command can be executed.
        // tags:
        //      public

        return declare([PasteContent], {

            typeDescriptorManager: TypeDescriptorManager,

            _onModelChange: function () {
                // summary:
                //      Updates canExecute after the model has been updated.
                // tags:
                //      protected override

         

                var selectedData = this.get("selectionData");

       // Set to false by default in case there are any timing delays in the deferred.
                this.set("canExecute", false);

                if (selectedData) {
                    var isCopyToProduct = this.clipboard.isCopy() && this._typeIsAssignableFrom(selectedData.typeIdentifier, ModelSupport.contentTypeIdentifier.productContent);

                    // Check the type identifier is base on both node and product content type.
                    if (this._typeIsAssignableFrom(selectedData.typeIdentifier, ModelSupport.contentTypeIdentifier.nodeContentBase) || isCopyToProduct) {
                        var self = this,
                            model = self.model,
                            source = self.get("clipboardData"),
                            target = self._getSingleSelectionData();

                        if (model && source && source.length && target) {
                            var deferreds = array.map(source, function (item) {
                                return model.canPaste(item.data, target, self.clipboard.copy);
                            });

                            when(promiseAll(deferreds), function (results) {
                                var canExecute = array.every(results, function (result) {
                                    return result;
                                });

                                if (self.clipboard.copy) {
                                    self.set("canExecute", canExecute);
                                    return;
                                }

                                // Check to make sure the target is not a descendant of the source.
                                model.getAncestors(target, function (ancestors) {
                                    var isDescendant = array.some(source, function (item) {
                                        return array.indexOf(ancestors, item.data) >= 0;
                                    });
                                    self.set("canExecute", canExecute && !isDescendant);
                                });
                            });
                        }
                    }
                }
            },

            _typeIsAssignableFrom: function (/*string*/ type, /*string*/ baseTypeToSupport) {
                return this.typeDescriptorManager.isBaseTypeIdentifier(type, baseTypeToSupport);
            }
        });
    });