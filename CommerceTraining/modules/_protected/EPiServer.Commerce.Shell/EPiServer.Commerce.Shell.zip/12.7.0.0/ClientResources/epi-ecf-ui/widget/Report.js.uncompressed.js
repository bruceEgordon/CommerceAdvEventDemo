require({cache:{
'url:epi-ecf-ui/widget/templates/Report.html':"﻿<div data-dojo-type=\"dijit/layout/ContentPane\" class=\"epi-report-container\">\r\n    <div data-dojo-attach-point=\"downloadLinksContainer\" class=\"epi-view-container\"></div>\r\n</div>"}});
﻿define("epi-ecf-ui/widget/Report", [
    // dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-construct",
    // dijit
    "dijit/_TemplatedMixin",
    "dijit/_WidgetBase",
    // template
    "dojo/text!./templates/Report.html",
    "epi/i18n!epi/cms/nls/commerce.report"
], function (
    // dojo
    declare,
    lang,
    domConstruct,
    // dijit
    _TemplatedMixin,
    _WidgetBase,
    // template
    template,
    reportingResources
) {
        // module:
        //      epi-ecf-ui.widget.Report
        // tags:
        //      protected

        return declare([_WidgetBase, _TemplatedMixin], {
            // summary:
            //      Report widget.
            // tags:
            //      public

            resources: reportingResources,

            templateString: template,

            postCreate: function () {
                this.inherited(arguments);

                this._renderDownloadLinks();
            },

            _renderDownloadLinks: function () {
                // summary:
                //      Renders report download links
                // tags:
                //      private

                // No files, do nothing.
                if (!(this.exportedFilesData instanceof Array) || this.exportedFilesData.length === 0) {
                    domConstruct.place("<span>" + this.resources.nofilesfound +"</span>", this.downloadLinksContainer);

                    return;
                }

                var reportLinkTags = "";
                for (var itemIndex in this.exportedFilesData) {
                    var reportLinkTag = lang.replace("<li><a class=\"epi-visibleLink\" href=\"{downloadUrl}\">{fileName}</a><li>", {
                        fileName: this.exportedFilesData[itemIndex].name,
                        downloadUrl: this.exportedFilesData[itemIndex].downloadUrl
                    });

                    reportLinkTags += reportLinkTag;
                }

                domConstruct.place("<ul>" + reportLinkTags + "</ul>", this.downloadLinksContainer);
            }
        });
    });